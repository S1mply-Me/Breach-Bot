#Breach Bot Starter Code
breachYear = 2019

#Greets user
print("Hello! I'm Breach Bot.")
userName = input("What is your name?\n ")
print("Nice to meet you " + userName)

#Recounts year of breach
todaysYear = input("What year is it?\n")
timePassed = int(todaysYear) - breachYear
print("Wow! That means it has been " + str(timePassed) + " years since the Facebook Data Breach!")


#Introduces breach
print("Would you like to learn about the Facebook Data Breach?")
giveInfo = input("Type 'yes' or 'no'\n")

#Explains breach
while giveInfo.lower() == "yes":
  print("What would you like to learn more about? Enter the lowercase letter of the following options: \n(a) breach details, (b) the organization's response, or (c) I would love to hear your reflection.")
  topic = input()
  
  if topic.lower() == "a":
    print("A data breach on Facebook by malicious actors affected 533 million users.The malicious actors exploited a no longer used feature’s vulnerability and grabbed chunks of data with a computer program, including phone numbers, full names, some emails, and some details from user profiles.")
  
  elif topic.lower() == "b":
    print("Facebook did not notify users because Facebook was unsure who needs to be notified. The company also did not recommend anything because the data was public and the users could do nothing to fix it themselves.")
  
  elif topic.lower() == "c":
    break
  
  else:
    print("Sorry, I didn't catch that. Choose one of the options listed.")
  
  input("Press enter to continue\n")


#Introduces my take
print("\n I'm excited to share my perspective with you. Are you ready to hear my take?")
giveInfo = input("Type 'yes' or 'no'\n")

#Shares my take
while giveInfo.lower() == "yes":
  print("What would you like to learn more about? Enter the lowercase letter of the following options: \n(a) relation to the CIA Triad, (b) my reaction, (c) my advice, or (d) none.")
  topic = input()

  if topic.lower() == "a":
    print("The data breach affected the confidentiality of the CIA Triad as the hackers gained access to private information.")

  elif topic.lower() == "b":
    print("We disagree with the organization's response because Facebook did not have the resources to notify users about the data breach even though it is worth billions of dollars and should have been able to. In addition, Facebook did not recommend the users to take action by saying the data is public even though the users can still take action to protect themselves like being on guard for scam calls.")

  elif topic.lower() == "c":
    print("I would convince victims to take action by checking the website haveibeenpwned.com to see what information has been compromised, not picking up scam calls, and be aware of identity theft and signs of identity theft.")

  elif topic.lower() == "d":
    break

  else:
    print("Sorry, I didn't catch that. Choose one of the options listed.")

  input("Press enter to continue\n")



#Chatbot ends conversation
print("Thanks for chatting with me, and I hope you learned something new!")